#ifndef AP_G711_H
#define AP_G711_H
int linear2alaw(int	pcm_val) ;
int linear2ulaw( int pcm_val);
#endif
