#include "../../global.h"
#include "avr/io.h"
#include <util/delay.h>
#include <avr/eeprom.h>
#include "Memory.h"

void storeTemperature(int temp){
	
}
