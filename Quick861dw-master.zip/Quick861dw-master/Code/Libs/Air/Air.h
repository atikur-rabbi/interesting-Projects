

#ifndef AIR_H
#define AIR_H


#define AIR_CAP_HIGH			100
#define AIR_CAP_LOW				1

int getAirSpeed();
void setAirSpeed(int speed);
void increaseAirSpeed(int number);
void decreaseAirSpeed(int number);

#endif